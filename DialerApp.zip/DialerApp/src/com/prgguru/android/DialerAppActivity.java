package com.prgguru.android;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DialerAppActivity extends Activity {
	/** Called when the activity is first created. */
	Button dialBtn;
	EditText numTxt;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		dialBtn = (Button) findViewById(R.id.button1);
		numTxt = (EditText) findViewById(R.id.editText1);
		dialBtn.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				try {
					if (numTxt != null && (numTxt.getText().length()==10 ||numTxt.getText().length()==11)) {
						startActivity(new Intent(Intent.ACTION_CALL, Uri
								.parse("tel:" + numTxt.getText())));
					}else if(numTxt != null && numTxt.getText().length()==0){
						Toast.makeText(getApplicationContext(), "You missed to type the number!", Toast.LENGTH_SHORT).show();
					}else if(numTxt != null && numTxt.getText().length()<10){
						Toast.makeText(getApplicationContext(), "Check whether you entered correct number!", Toast.LENGTH_SHORT).show();
					}
				} catch (Exception e) {
					Log.e("DialerAppActivity", "error: " + e.getMessage(),
							e);
				}
			}
		});
	}
}